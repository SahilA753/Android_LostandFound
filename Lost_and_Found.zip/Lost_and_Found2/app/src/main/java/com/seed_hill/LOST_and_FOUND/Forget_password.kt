package com.seed_hill.LOST_and_FOUND

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.seed_hill.LOST_and_FOUND.databinding.ActivityForgetPasswordBinding


class Forget_password : AppCompatActivity() {
    private lateinit var binding: ActivityForgetPasswordBinding
    private lateinit var firebaseAuth: FirebaseAuth
   // private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityForgetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        firebaseAuth=FirebaseAuth.getInstance()


//        progressDialog= ProgressDialog(this)
//        progressDialog.setTitle("Please wait")
//        progressDialog.setCanceledOnTouchOutside(false)
        binding.buttonMail.setOnClickListener {
            validateData()
        }
        binding.mailme2.setOnClickListener {
            val intent= Intent(this,Forget_password::class.java)
            startActivity(intent)
        }
    }

    private var email=""
    private fun validateData() {

        email=binding.emailInput.text.toString().trim()
        if(email.isEmpty()){
            Toast.makeText(this,"Enter email...",Toast.LENGTH_SHORT).show()
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            Toast.makeText(this,"Invalid email pattern...",Toast.LENGTH_SHORT).show()

        }
        else {
            recoverPassword()
        }
    }

    private fun recoverPassword() {
//        progressDialog.setMessage("Sending password reset instructions to $email")
        firebaseAuth.sendPasswordResetEmail(email)
            .addOnSuccessListener {
//                progressDialog.dismiss()
                Toast.makeText(this,"Instructions sent to $email",Toast.LENGTH_SHORT).show()

            }
            .addOnFailureListener{

                Toast.makeText(this,"Failed due to some reason",Toast.LENGTH_SHORT).show()
            }
    }
}


