package com.seed_hill.LOST_and_FOUND

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.seed_hill.LOST_and_FOUND.databinding.ActivityInsideApp1Binding
import com.seed_hill.LOST_and_FOUND.databinding.ActivityInsideApp2Binding
import com.seed_hill.LOST_and_FOUND.databinding.ActivityMainBinding

class insideApp2 : AppCompatActivity() {
    private lateinit var binding: ActivityInsideApp2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inside_app1)
        binding= ActivityInsideApp2Binding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.HomeINAPP.setOnClickListener {
            //Toast.makeText(this,"Signing-In...",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,insideApp1::class.java)
            startActivity(intent)

        }

        binding.SettingsINAPP.setOnClickListener {
       //Toast.makeText(this,"Signing-In...",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,insideApp1::class.java)
            startActivity(intent)
        }
    }
}