package com.seed_hill.LOST_and_FOUND

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.seed_hill.LOST_and_FOUND.databinding.ActivitySignUpBinding
import com.seed_hill.LOST_and_FOUND.model.UserModel
import java.util.Date

class Sign_Up : AppCompatActivity() {
     lateinit var binding: ActivitySignUpBinding
     lateinit var firebaseAuth: FirebaseAuth
     lateinit var database : FirebaseDatabase
     lateinit var storage : FirebaseStorage
     lateinit var selectedImg : Uri
     lateinit var dialog : AlertDialog.Builder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        firebaseAuth=FirebaseAuth.getInstance()
        dialog= AlertDialog.Builder(this)
            .setMessage("Uploading Profile...")
            .setCancelable(false)
        database = FirebaseDatabase.getInstance()
        storage = FirebaseStorage.getInstance()
        binding.signupProfilepic.setOnClickListener {
            val intent = Intent()
            intent.action=Intent.ACTION_GET_CONTENT
            intent.type="image/*"
            startActivityForResult(intent,1)




        }

        binding.alreadyreg.setOnClickListener {
            Toast.makeText(this,"Signing-In...",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,Post_for_lost_item::class.java)
            startActivity(intent)
        }

        binding.RegisterSignup.setOnClickListener {
            val email = binding.signupMailid.text.toString()
            val pwd=binding.signupPassword.text.toString()
            val confirmpwd=binding.signupConfirmpassword.text.toString()
            val user= binding.signupName.text.toString()
            val contact= binding.signuppContact.text.toString()

            if(email.isNotEmpty()&&pwd.isNotEmpty()&&confirmpwd.isNotEmpty()&&contact.isNotEmpty()&&user.isNotEmpty())
            {
                if(pwd.equals(confirmpwd))
                {
                    if(selectedImg==null){
                        Toast.makeText(this,"Please Upload Image!",Toast.LENGTH_SHORT).show()

                    }
                    else {
                        uploadData()
                        firebaseAuth.createUserWithEmailAndPassword(email, pwd)
                            .addOnCompleteListener {
                                if (it.isSuccessful) {
                                    Toast.makeText(this, "Registering...", Toast.LENGTH_SHORT)
                                        .show()
                                    val intent = Intent(this, insideApp1::class.java)
                                    startActivity(intent)
                                } else {
                                    Toast.makeText(
                                        this,
                                        it.exception.toString(),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    }

                }
                else
                {
                    Toast.makeText(this,"Password in the fields do not match!!",Toast.LENGTH_SHORT).show()
                }
            }
            else {
                Toast.makeText(this,"Empty fields are not allowed",Toast.LENGTH_SHORT).show()
            }
            }

        }

    private fun uploadData() {
       val reference = storage.reference.child("Profile").child(Date().time.toString())
        reference.putFile(selectedImg).addOnCompleteListener{
            if(it.isSuccessful){
                reference.downloadUrl.addOnSuccessListener { task->
                    uploadInfo(task.toString())

                }
            }
        }
    }

    private fun uploadInfo(imgUrl: String) {
        val user=UserModel(firebaseAuth.uid.toString(), binding.signupName.text.toString(),binding.signuppContact.text.toString(),imgUrl)
      database.reference.child("users")
          .child(firebaseAuth.uid.toString())
          .setValue(user)
          .addOnSuccessListener {
              Toast.makeText(this,"Data Inserted",Toast.LENGTH_SHORT).show()
              startActivity(Intent(this,MainActivity::class.java))
              finish()
          }
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode, resultCode, data)
        if(data!=null){
            if(data.data!=null){
                selectedImg=data.data!!
                binding.signupProfilepic.setImageURI(selectedImg)
            }
        }
    }








}
