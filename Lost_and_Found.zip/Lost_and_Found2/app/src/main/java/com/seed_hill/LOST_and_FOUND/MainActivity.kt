package com.seed_hill.LOST_and_FOUND

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.seed_hill.LOST_and_FOUND.databinding.ActivityMainBinding
import com.seed_hill.LOST_and_FOUND.databinding.ActivitySignUpBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        firebaseAuth=FirebaseAuth.getInstance()
       binding.signUp.setOnClickListener {
           Toast.makeText(this,"Signing-Up...",Toast.LENGTH_SHORT).show()
           val intent = Intent(this,Sign_Up::class.java)
           startActivity(intent)
       }
        binding.forgotpassword.setOnClickListener {
            val intent=Intent(this,Forget_password::class.java)
            startActivity(intent)
        }
        binding.loginButton.setOnClickListener {
            val email= binding.emailInput.text.toString()
            val pwd=binding.passwordInput.text.toString()
            if(pwd.isNotEmpty()&&email.isNotEmpty())
            {
                firebaseAuth.signInWithEmailAndPassword(email,pwd).addOnCompleteListener {
                    if(it.isSuccessful) {
                        Toast.makeText(this,"Signing In...",Toast.LENGTH_SHORT).show()
                        val intent = Intent(this,insideApp1::class.java)
                        startActivity(intent)
                    }
                    else {
                        Toast.makeText(this,"Incorrect password or username, please enter again!",Toast.LENGTH_SHORT).show()
                    }
                }

            }
            else {
                Toast.makeText(this,"Empty fields are not allowed",Toast.LENGTH_SHORT).show()
            }
            }



        }
    }
