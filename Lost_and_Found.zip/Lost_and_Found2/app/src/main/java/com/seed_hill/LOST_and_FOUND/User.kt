package com.seed_hill.LOST_and_FOUND

data class User(var username :String ?= null,var email :String?=null, var password :String?=null,)
