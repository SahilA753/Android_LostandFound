package com.seed_hill.LOST_and_FOUND.model

data class Data_Lost_upload(
                            val fullName:String,
                            val phoneNumber:String,
                            val locationLost:String,
                            val message :String,
                            val imageUrl: String,
                            )
