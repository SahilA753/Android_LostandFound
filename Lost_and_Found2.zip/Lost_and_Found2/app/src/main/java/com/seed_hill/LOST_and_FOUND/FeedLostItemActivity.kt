package com.seed_hill.LOST_and_FOUND

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.content.Intent

import android.util.Log
import android.view.Window

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.google.firebase.firestore.*
import com.google.firebase.firestore.R
import com.seed_hill.LOST_and_FOUND.databinding.ActivityFeedLostItemBinding

class FeedLostItemActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFeedLostItemBinding
    private lateinit var userArrayList: ArrayList<LostItems>
    private lateinit var recyclerView: RecyclerView
    private lateinit var myAdapterLostItems: MyAdapterLostItems
    private lateinit var db: FirebaseFirestore


    override fun onCreate(savedInstanceState: Bundle?) {


        requestWindowFeature(Window.FEATURE_NO_TITLE) //will hide the title
        supportActionBar?.hide() //hide the title bar
        super.onCreate(savedInstanceState)
        binding = ActivityFeedLostItemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = binding.recycleViewLostfeed
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)

        userArrayList = arrayListOf()

        myAdapterLostItems = MyAdapterLostItems(this, userArrayList)

        recyclerView.adapter = myAdapterLostItems

        eventChangeListener()

        binding.textView4.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


    }

    private fun eventChangeListener(){

        db = FirebaseFirestore.getInstance()
        db.collection("Found Items").addSnapshotListener(object: EventListener<QuerySnapshot>{
            override fun onEvent(value: QuerySnapshot?, error: FirebaseFirestoreException?) {
                if(error!= null){
                    Log.e("Firestore Error", error.message.toString())
                    return
                }
                for(dc: DocumentChange in value?.documentChanges!!){

                    if(dc.type == DocumentChange.Type.ADDED){
                        userArrayList.add(dc.document.toObject(LostItems::class.java))
                    }
                }
                myAdapterLostItems.notifyDataSetChanged()
            }

        })

    }
}