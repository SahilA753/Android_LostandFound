package com.seed_hill.LOST_and_FOUND

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.seed_hill.LOST_and_FOUND.databinding.ActivityInsideApp1Binding
import com.seed_hill.LOST_and_FOUND.databinding.ActivityInsideApp2Binding
import com.seed_hill.LOST_and_FOUND.databinding.ActivityMainBinding

class insideApp1 : AppCompatActivity() {
    private lateinit var binding: ActivityInsideApp1Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inside_app1)
        binding= ActivityInsideApp1Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.PostForLostItemInapp.setOnClickListener {
            //Toast.makeText(this,"Signing-In...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this,Post_for_lost_item::class.java)
            startActivity(intent)
        }
        binding.PostForFoundItemINAPP.setOnClickListener {
            val intent = Intent(this,Post_for_found_item::class.java)
            startActivity(intent)

        }
        binding.CheckForLostItemsInapp.setOnClickListener {
            //Toast.makeText(this,"Signing-In...",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,FeedLostItemActivity::class.java)
            startActivity(intent)
        }
        binding.CheckForFoundItemsINAPP.setOnClickListener {

        }
        binding.MypostsINAPP.setOnClickListener {
            //Toast.makeText(this,"Signing-In...",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,insideApp2::class.java)
            startActivity(intent)

        }
        binding.SettingsINAPP.setOnClickListener {
            val intent = Intent(this,insideApp3::class.java)
            startActivity(intent)
        }
    }
}