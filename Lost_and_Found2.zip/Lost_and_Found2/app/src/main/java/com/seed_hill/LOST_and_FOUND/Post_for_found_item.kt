package com.seed_hill.LOST_and_FOUND

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.seed_hill.LOST_and_FOUND.databinding.ActivityPostForFoundItemBinding
import com.seed_hill.LOST_and_FOUND.databinding.ActivityPostForLostItemBinding
import com.seed_hill.LOST_and_FOUND.model.Data_Lost_upload
import java.util.*

class Post_for_found_item : AppCompatActivity() {
    lateinit var binding: ActivityPostForFoundItemBinding
    lateinit var firebaseAuth: FirebaseAuth
    lateinit var database: FirebaseDatabase
    lateinit var storage: FirebaseStorage
    lateinit var selectedImg: Uri
    lateinit var store:String

    lateinit var dialog: AlertDialog.Builder
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPostForFoundItemBinding.inflate(layoutInflater)
        firebaseAuth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        storage = FirebaseStorage.getInstance()
        dialog = AlertDialog.Builder(this)
            .setMessage("Uploading Post!")
            .setCancelable(false)
        setContentView(binding.root)


        binding.PostdataLost.setOnClickListener {
            val description = binding.descriptionAboutLost.text.toString()
            val phonenumber=binding.phonenumber.text.toString()
            val location=binding.locationLost.text.toString()
            val fullname=binding.fullName.text.toString()
            if (selectedImg == null ) {
                Toast.makeText(this, "Please Upload Image!", Toast.LENGTH_SHORT).show()
            } else {
                if (description.isNotEmpty()&&phonenumber.isNotEmpty()&&location.isNotEmpty()&&fullname.isNotEmpty()) {
                    uploadData()
                    Toast.makeText(this, "Inserting data!!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Empty fields are not allowed", Toast.LENGTH_SHORT).show()
                }

            }

        }


    }

    private fun uploadData() {
        val reference = storage.reference.child("FoundItems").child(Date().time.toString())
        reference.putFile(selectedImg).addOnCompleteListener {
            if(it.isSuccessful)
            {
                reference.downloadUrl.addOnSuccessListener {
                        task->uploadInfo(task.toString())
                }
            }
        }






    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)


        if (data != null) {
            if (data.data != null) {
                selectedImg = data.data!!
                binding.openImageList.setImageURI(selectedImg)
            }
        }


    }


    fun uploadInfo1(imgUrl: String) {
        store=imgUrl

    }



    fun uploadInfo(imgUrl: String,) {
//        val user = Data_Lost_upload(
//            firebaseAuth.uid.toString(),
//            binding.descriptionAboutLost.text.toString(),
//            firebaseAuth.currentUser!!.displayName.toString(),
//            imgUrl,imgUrl1,imgUrl2,imgUrl3,imgUrl4
//        )
        val user = Data_Lost_upload(
            binding.fullName.text.toString(),
            binding.phonenumber.text.toString()
            ,binding.locationLost.text.toString(),
            binding.descriptionAboutLost.text.toString(),
            imgUrl
        )
        database.reference.child("LostItems")
            .child(firebaseAuth.uid.toString())
            .setValue(user)
            .addOnSuccessListener {
                Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, Post_for_lost_item::class.java))
                finish()
            }
    }
}