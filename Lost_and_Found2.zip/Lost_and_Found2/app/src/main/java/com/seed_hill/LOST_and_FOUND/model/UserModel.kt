package com.seed_hill.LOST_and_FOUND.model

data class UserModel(
    val uid: String,
    val name:String,
    val phoneNumber:String,
    val imageUrl: String
)
